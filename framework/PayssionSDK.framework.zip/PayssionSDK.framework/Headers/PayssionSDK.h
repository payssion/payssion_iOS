//
//  PayssionSDK.h
//  PayssionSDK
//
//  Created by UlquiorraCifer on 16/11/24.
//  Copyright © 2016年 Payssion. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import <PayssionSDK/MySDKTest.h>
#import <PayssionSDK/PaymentMainController.h>

//! Project version number for PayssionSDK.
FOUNDATION_EXPORT double PayssionSDKVersionNumber;

//! Project version string for PayssionSDK.
FOUNDATION_EXPORT const unsigned char PayssionSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PayssionSDK/PublicHeader.h>


