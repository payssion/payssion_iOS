//
//  MySDKTest.h
//  PayssionSDK
//
//  Created by UlquiorraCifer on 16/11/24.
//  Copyright © 2016年 Payssion. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MySDKTest : NSObject

+ (void)printTest;

@end
