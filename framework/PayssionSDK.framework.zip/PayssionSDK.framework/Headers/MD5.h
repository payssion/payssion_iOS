//
//  MD5.h
//  Payssion-Example
//
//  Created by UlquiorraCifer on 16/11/22.
//  Copyright © 2016年 Payssion. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MD5 : NSObject

+(NSString *) md5: (NSString *) inPutText;

@end
